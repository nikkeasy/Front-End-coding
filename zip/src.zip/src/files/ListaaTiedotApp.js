import React from 'react';
import ListaaTiedot from '../components/ListaaTiedot';
import ListOldUsersApp from './ListOldUsers';

function ListaaTiedotApp () { 
    return( 
        <div> 
            <ListaaTiedot/>
            <ListOldUsersApp/>
        </div>


    )

}

export default ListaaTiedotApp;