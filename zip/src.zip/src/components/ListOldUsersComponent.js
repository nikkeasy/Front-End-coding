// ks esimerkki object.valuesista 

import React from 'react'; 

function ListOldUsersComponent (props) { 
    return ( 
            <div> 
                { props.oldusers.map (list => {
                    return ( 
                        <p key={ list.first_name }>
                            Id: { list.id } <br />
                            First Name {list.first_name } <br />
                            Last Name {list.last_name } <br /> 
                            Country: {list.country } <br />
                            Gender: {list.gender } <br />
                            Ip address {list.ip_address }
                        </p> );
                })
            }    
                
            
         </div>  );




        }

export default ListOldUsersComponent; 