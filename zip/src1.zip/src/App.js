import React from 'react';
import './App.css';
import ListaaTiedotApp from './files/ListaaTiedotApp';

function App() {
  return (
    <div>
  
<ListaaTiedotApp/>

    </div>
  );
}

export default App;
