import React from 'react';
import ListaaTiedot from '../components/ListaaTiedot';
import ListOldUsersComponent from '../components/ListOldUsersComponent';

function ListaaTiedotApp () { 
    return( 
        <div> 
            <ListaaTiedot/>
            <ListOldUsersComponent/>
        </div>


    )

}

export default ListaaTiedotApp;